function [X,V] = protokEK(C)
pocetnaMatrica=C;
m=size(C, 1);
pomocna_lista = nadjiProtok(C);
da=1;
V=0;
while pomocna_lista(size(pomocna_lista,2))~=0 & da~=0
[min, da, C] = promjenaMatrice(C, pomocna_lista);
pomocna_lista = nadjiProtok(C);
V=V+min;
end

for i=1:m
    for j=1:m
        if pocetnaMatrica(i,j)~=0
            pocetnaMatrica(i,j)=C(j,i);
        end
    end
end
X=pocetnaMatrica;
end

function [pomocna_lista] = nadjiProtok(C) 
m=size(C, 1);
pomocna_lista = zeros(m,2); %Pravimo listu koja nam govori za svaki cvor koliko je udaljen od pocetka i sa kojeg cvora je upuceno na taj cvor
pomocna_lista(1,:)=[0,0];
najkraca=1; %trenutna najkraca udaljenost
%nalazimo cvorove do kojih se moze doci iz prvog cvora
for k=1:m
    if C(1,k)~=0 
        pomocna_lista(k,1)=1;
        pomocna_lista(k,2)=1;
    end 
end
%nalazimo ostale
for i=1:m
    for j=1:m
        for k=1:m
        if C(j,k)~=0 & pomocna_lista(j,1)==najkraca  & pomocna_lista(k,2)==0
            pomocna_lista(k,1)=najkraca+1;
            pomocna_lista(k,2)=j;
            
        end       
        end
    end
    najkraca=najkraca+1;
end
pomocna_lista(1,:)=[0,0];
end

function [min,da, matrica] = promjenaMatrice(C, pomocna_lista)
    m=size(C,1);
    if pomocna_lista(m,1)==0
        da=0;
        matrica=C;
        min=0;
    else
        da=1;
        lista=[];
        trenutni=m;
        i=1;
        while trenutni~=1
            if pomocna_lista(trenutni,2)~=0 
              lista=[lista; [pomocna_lista(trenutni,2), trenutni]];
              trenutni=[pomocna_lista(trenutni,2)];
            
            else 
                da=0;
                trenutni=1;
            end
                
        end
        %nalazenje najmanjeg elementa koji je ozancen u tabeli
        min=100000;
        indeksi=0;
        for i=1:size(lista,1)
            if C(lista(i,1), lista(i,2))<min & C(lista(i,1), lista(i,2))>0
                min = C(lista(i,1), lista(i,2));
                indeksi = lista (i,:);
            end
        end
        
        %sada vrsimo promjenu matrice
        for i=1:size(lista,1)
            C(lista(i,1), lista(i,2))=C(lista(i,1), lista(i,2))-min;
             C(lista(i,2), lista(i,1))=C(lista(i,2), lista(i,1))+min;
        end
        matrica = C;
    end
end