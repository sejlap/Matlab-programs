function [T,V]=Kruskal(E) 
    V=0;
    T=[];
    %%Sortiranje grana
    E = sortrows(E,3);
    %%Broj cvorova n - maksimalni element u drugoj koloni matrice E
    n=max(E(:,2));
    %%Pomocna matrica 1.red referentni cvor, 2. red tezina cvora; kolona -
    %%indeks cvora
    i = 1; %%indeks grane
    pom = [zeros(1,n); ones(1,n)]; %%Na pocetku referentni cvor nula, a tezina 1
    uzete = 0;
    while uzete<n-1 
        grana = E(i, :);
        i = i+1;
        %%Trazimo korjenske cvorove p i q
        c_i = grana(1,1);
        c_j = grana(1,2);
        %%Korijenski cvor p
        p=c_i;
        if pom(1,c_i)~=0
            while pom(1,p)~=0
                p = pom(1,p);
            end
        end
        %%Korijenski cvor q
        q = c_j;
        if pom(1,c_j)~=0
            while pom(1,q)~=0
                q = pom(1,q);
            end
        end
        %%Provjeravamo da li granu smijemo uzeti
        if p ~= q || p==0 
            if p==0
                pom(2,p)= pom(2,p)+pom(2,q);
                pom(1,q) = p;
            %%Smijemo ih uzeti - vrsimo korekciju
            elseif pom(2,p)<pom(2,q) %%Manju tezinu ima cvor p
                pom(1,p) = q;
                pom(2,q) = pom(2,q)+pom(2,p);
            else
                pom(1,q) = p;
                pom(2,p) = pom(2,p)+pom(2,q);
            end
            T = [T; c_i c_j];
            uzete = uzete+1;
            V = V + E(i-1,3);
        else
            continue; %%Ne smijemo ih uzeti
        end
    end
end