function [X, V] = transport (C, S, P)
    S = S';
    [a, b] = size(C);
    if sum(S) > sum(P) %vi�e izvora nego odredi�ta -- dodamo fiktivno odredi�te
        dodatna = ones(1, 1);
        dodatna(1, 1) = sum(S) - sum(P);
        P = horzcat (P, dodatna);
        dodatneCijene = zeros(a, 1);
        C = horzcat(C, dodatneCijene);
    elseif sum(P) > sum(S) %vi�e odredi�ta nego izvora -- dodamo fiktivni izvor
        dodatna = ones(1, 1);
        dodatna(1, 1) = sum(P) - sum(S);
        S = vertcat(S, dodatna);
        dodatneCijene = zeros(1, b);
        C = vertcat(C, dodatneCijene);
    end
    [a, b] = size(C);
    %sada pravimo funkciju cilja koja se sastoji od svih cijena
    %funkciju ne treba mno�iti sa -1 jer se tra�i minimum
    f = zeros(1, a*b);
    brojac = 1;
    for i = 1 : a
        for j = 1 : b
            f(1, brojac) = C(i, j);
            brojac = brojac + 1;
        end
    end
    %ukupno ima a*b promjenjivih i size(S)+size(P) ograni�enja -- to je
    %veli�ina na�e matrice Aeq
    [s, nevazno] = size(S);
    [nevazno, p]= size(P);
    Aeq = zeros (s + p, a * b);
    brojac = 1;
    for i = 1 : a
        for j = 1 : b
            Aeq(i, brojac) = 1;
            brojac = brojac + 1;
        end
    end
    brojac = b;
    j1 = 1;
    j2 = 1;
    for i = a + 1 : s + p
        while j1 <= a * b
            Aeq(i, j1) = 1;
            j1 = j1 + brojac;
        end
        j1 = j2 + 1;
        j2 = j2 + 1;
    end
    %sada formiramo Beq -- velicine S + P
    Beq = vertcat(S, P');
    lb = zeros(1, a * b);
    ub = Inf(1, a * b, 'double');
    opcije=optimset('LargeScale','off','Display','off'); 
    [x, v, exit, output, lambda] = linprog (f, [], [], Aeq, Beq, lb, ub, [], opcije);
    %x cemo pretvoriti u matricu istog oblika kao i C da se jasno vidi
    %preko kojih polja se vr�i transport
    brojac = 1;
    X = zeros(a, b);
    for i = 1 : a
        for j = 1 : b
            X(i, j) = x(brojac, 1);
            brojac = brojac + 1;
        end
    end
    V = v;
    disp(X);
    disp(V);
end
    