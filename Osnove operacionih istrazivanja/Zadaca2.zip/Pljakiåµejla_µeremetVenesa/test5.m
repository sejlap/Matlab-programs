function []=test5()
%Z=Inf; Funkcija cilja nije ogranicena, rjesenja u beskonacnosti; status(3)
goal='max';

c=[40 30];
A=[0.1 0; 0 0.1; 0.5 0.3; 0.1 0.2];
b=[0.2;0.3;3;1.2];
csigns=[1;1;1;1];
vsigns=[1; 1];
[Z,X,Xd,Y,Yd,status]=general_simplex(goal,c,A,b,csigns,vsigns)