function []=test7()
%Z=52; X=(4,4; Xd=(2 2 0 0); Y=(0 0 4 9); Yd=(0 0) status(2)
goal='max';

c=[4 9];
A=[1 0 ; 0 1 ; 1 0; 0 1];
b=[2; 2; 4; 4];
csigns=[1;1;-1;-1];
vsigns=[0; 0];
[Z,X,Xd,Y,Yd,status]=general_simplex(goal,c,A,b,csigns,vsigns)