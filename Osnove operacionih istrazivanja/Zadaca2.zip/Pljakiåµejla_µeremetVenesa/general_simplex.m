
function [Z,X,Xd,Y,Yd,status] = general_simplex(goal,c,A,b,csigns,vsigns)
    
    status=0;
    
    vsigns=vsigns.';
    % Validacija goal  
    if goal~='min'& goal~='max'
        status=5;
        Z=nan;
        error('Neispravna vrijednost parametra goal');
       
    end
    
    % Validacija dimenzija matrica
    [r,k]=size(A);
    if(r~=size(b,1) || k~=size(c,2)) 
        status=5;
        Z=nan;
        error ('Neispravne dimenzije parametara.');
    end
    vel_csigns = size(csigns, 1);
    vel_vsigns = size(vsigns, 2);
    
    %Validacija csign
    if vel_csigns~=r 
        status=5;
        Z=nan;
        error ('Neispravne dimenzije vektora csign');
    end
    for i=1:vel_csigns
        if csigns(i,1)~=0 & csigns(i,1)~=1 & csigns(i,1)~=-1
            status=5;
            Z=nan;
            error ('Neispravne vrijednsti elemenata vektora csign');
        end
   
    end   
    %Validacija vsign
     if vel_vsigns~=k 
        status=5;
        Z=nan;
        error ('Neispravne dimenzije vektora vsign');
    end
    for i=1:vel_vsigns
        if vsigns(1,i)~=0 & vsigns(1,i)~=1 & vsigns(1,i)~=-1
            status=5;
            Z=nan;
            error ('Neispravne vrijednsti elemenata vektora vsign');
        end
    end
    
    %Svodjenje f-je cilja na problem maksimuma
    if goal=='min'
        c=-c;
    end
   
    %Provjeravamo je li b negativno
    for i=1:size(b,1)
        if b(i,1)<0
            A(i, :)=-A(i, :);
            b(i,1)=-b(i,1);
        end
    end
    %Pocetna simplex tabela
    simplex_tabela=[A;c];
    r=r+1; %jer sada simplex tabela ima jedan red vi?e
    
    %Pomocna matrica koja nam govori koje smjene smo uveli
    matrica_smjena=ones(1,k);
    
    %Svodjenje ogranicenja za promjenjive na normalni oblik
    pom_vel=k;
    j=0; %Broj dodanih kolona u tabeli
    for i=1:pom_vel
        if vsigns(1,i)==0
            matrica_smjena(1,i)=2;
            simplex_tabela=[simplex_tabela(:, 1:(i+j)) -1.*simplex_tabela(:,(i+j)) simplex_tabela(:, (i+j+1):k)];
            k=k+1;
            j=j+1;
        elseif vsigns(1,i)==-1
            simplex_tabela(:,(i+j))=-1.*simplex_tabela(:,(i+j));
        end
    end
    
    %Pomocni red koji cuva indekse vjestackih promjenjivih
    %indeksi_vjestackih=[];
    
    %Vektor kaznenih koeficijenata 
    M=[0];
    %vektor indeksa baznih promjenjivih
    baza=zeros(r-1, 1);
    
    %Svodjenje ogranicenja na normalni oblik
    
    %Slobodni clanovi uz M
    M_free = 0;
    niz_vjestackih=[];
    
    for i=1:vel_csigns
        pomocna_kolona=zeros(r,1);
        if csigns(i,1)==-1
            pomocna_kolona(i,1)=1;
            simplex_tabela=[simplex_tabela pomocna_kolona];
             M=[M, 0];
            
        elseif csigns(i,1)==0
            pomocna_kolona(i,1)=1;
            simplex_tabela=[simplex_tabela pomocna_kolona];
            i_vjestacke=size(simplex_tabela, 2);
            niz_vjestackih=[niz_vjestackih i_vjestacke];
            M=[M, zeros(1,i_vjestacke - size(M,2))];
            M=M-simplex_tabela(i, 1:i_vjestacke);
            M_free=M_free+b(i,1);
            
        else
            pomocna_kolona(i,1)=-1;
            simplex_tabela=[simplex_tabela pomocna_kolona];
            pomocna_kolona(i,1)=1;
            simplex_tabela=[simplex_tabela pomocna_kolona];    
            i_vjestacke=size(simplex_tabela, 2);           
            niz_vjestackih=[niz_vjestackih i_vjestacke];
            M=[M, zeros(1,i_vjestacke - size(M,2))];
            M=M-simplex_tabela(i, 1:i_vjestacke);
            M_free=M_free+b(i,1);
        end
         baza(i,1)=size(simplex_tabela, 2);
    end
    
    %Dodajemo i b kolonu u simplex tabelu
    simplex_tabela=[simplex_tabela [b;0]];
       
    %Svaki problem smo sveli na problem maximuma pa M treba biti sa
    %negativnim predznakom i dodajemo jos slobodni clan uz M
    M=[M -M_free];
    M=-M;
    
    %Anuliramo M uz vjestacke u tabeli
    for m=1:size(niz_vjestackih,2)
        M(niz_vjestackih(m))=0;
    end
    
    [Xp,Z,tabela,status, baza]=rijesi_simpleks(simplex_tabela, baza, M, status, niz_vjestackih);
    
    
    if goal=='min'
        Z=-Z;
    end
    
    zadnji_red=-tabela(size(tabela,1), 1:size(tabela, 2)-1);
    zadnji_index = 1;
    X=zeros(1, size(c,2));
    Yd=zeros(1, size(c,2));
    
    Xd=[];
    Y=[];
    
    for m=1:size(baza,1)
        [da]=je_li_vjestacka(niz_vjestackih, baza(m,1));
        
        if da==1
            status=4;
            Z=NaN;
            return;
        end
    end
    
    for i=1:size(matrica_smjena,2)
        if matrica_smjena(1,i)==2 
            X(1,i)=Xp(1,zadnji_index)+Xp(1,zadnji_index+1);
            Yd(1,i)=zadnji_red(1,zadnji_index)+zadnji_red(1,zadnji_index+1);
            zadnji_index = zadnji_index+1;
        else
            X(1,i)=Xp(1,zadnji_index);
            Yd(1,i)=zadnji_red(1,zadnji_index);
        end
        zadnji_index=zadnji_index+1;
    end
    
    for i=zadnji_index:size(Xp,2)
        jv=1;
        for j=1:size(niz_vjestackih,2)
            if(i==niz_vjestackih(1,j)) 
                jv=0;
                break;
            end
        end
        if jv==1 
            Xd=[Xd Xp(1,i)];
            Y=[Y zadnji_red(1,i)];
        end
    end
    
    %Provjera degeneracije
    if status==0 || status==2
    for i=1:size(X,2)
        if X(1,i)==0
            status=1;
            break;
        end
    end
    end
    if isnan(Z)==1
          status=4; %%provjeritiii
     end
end


%Pomo?na funkcija

function [x_opt, Z_opt, tabela, status, baza]=rijesi_simpleks(simplex_tabela, baza, M, status, niz_vjestackih)
    
   ima_M=1;
   if M==zeros(1, size(M,2)); 
       ima_M=0;
   end
       
   [r,k]=size(simplex_tabela);
   max_koef=1;
   
   while max_koef>0
       
       t=inf.*(ones(r-1,1));
       
   % trazenje max koeficijenta
   
  %Prvo pretrazujemo maximalnu vrijednost u redu gdje se nalaze
  %koeficijenti uz M, ako imamo M
  
       if ima_M==1
           [vrijednost_m,q] = max(M(1, 1:k-1));
           max_koef=vrijednost_m;
       else
           [vrijednost_q,q] = max(simplex_tabela(r,1:k-1)); %zadnji red u simplex tabeli su koef funkcije cilja
           max_koef=vrijednost_q;
           
       end
       if max_koef<1e-6
           break;
       end
       
   % Provjera da li je f-ja neograni?ena, da li je neki element negativan
     
   pomocni=simplex_tabela(1:r-1 ,q)<=0;
     if pomocni==ones(r-1,k)
         status=3;
         Z_opt=inf;
         x_opt=simplex_tabela(r, 1:k-1);
         tabela=simplex_tabela;
         return;
     end
   % trazenje vodeceg reda pomcu tmax 
       for i=1:1:r-1 
          if simplex_tabela(i, q)>0
            t(i)=simplex_tabela(i,k)/ simplex_tabela(i, q); %dijelimo b sa svim elementima u vodecoj koloni (osim sa negativnim)
          end    
       end  
   
      [vrijednost_p,p] = min(t);
      
      
      % Ako vjestacka promjenjiva izlazi iz baze nju vise ne uzimamo u
      % razmatranje u tabeli pa tu kolonu postavljamo na nule
      [da]=je_li_vjestacka(niz_vjestackih, baza(p));
      
      if da==1
          simplex_tabela(:,baza(p))=zeros(r,1);
          M(1,baza(p))=0;
      end
      
      %kad smo nasli vodeci red i kolonu mijenjamo red baza
      baza(p)=q;
      
      
      
      %mnozimo vodeci red sa koeficijentom takvim da koef. vodeceg elemanta
      %bude 1
      pom_koef=1/simplex_tabela(p,q);
      simplex_tabela(p, :)=simplex_tabela(p, :).*pom_koef;
      
     
      %sada cemo sve ostale koef u vodecoj koloni nastimati na 0,
      %ukljucujuci i  kolonu b
      for i=1:1:r
          if(i~=p)
              pom=(simplex_tabela(i,q));
             simplex_tabela(i, :)=simplex_tabela(i, :)-simplex_tabela(p, :).*pom; 
          end
      end
      
      %Ispitujemo je li b negativno, ako jeste dopustiva oblast ne postoji
      t2=simplex_tabela(1:r-1 ,k);
      for i=1:r-1
          if t2(i,1)<0
              Z=nan;
              status=4;
              x_opt=simplex_tabela(r, 1:k-1);
              tabela=simplex_tabela;
              return;
          end
      end
      
      %Ako imamo koeficijente uz M a?uriramo i njegove vrijednosti
      if ima_M==1
          pom=(M(1,q));
          M(1, :)=M(1, :)-simplex_tabela(p, :).*pom; 
      end
      if max(M)<=0.0000001
          ima_M=0;
      end
   end
    optimalno_rjesenje=zeros(1, k-1);
      for i=1:1:r-1
          optimalno_rjesenje(1, baza(i))=simplex_tabela(i, k);
          %optimalno_rjesenje(baza(v))=b(v);
      end
      
      for i=1:k-1 %prolazi kroz zadnji red
          pom=0;
          for j=1:r-1 %prolazi kroz bazu
              if baza(j)==i
                  pom=1;             
              end
          end
          if pom==0 & simplex_tabela(r, i)==0
              status=2
              break;
          end
      end
      
              
      x_opt=optimalno_rjesenje;
      Z_opt=-simplex_tabela(r, k);
      tabela=simplex_tabela;
      
end

function [da] = je_li_vjestacka (niz_indeksa, indeks)
    for i=1:size(niz_indeksa,2)
        if indeks==niz_indeksa(1,i) 
            da=1;
            return;
        end
    end
    da=0;
end


            