function []=test6()
%Z=Inf; Funkcija cilja nije ogranicena, rjesenja u beskonacnosti; status(3)
goal='max';

c=[4 9];
A=[1 3; 2 1; 1 2];
b=[100;300;200];
csigns=[1;1;1];
vsigns=[0; 0];
[Z,X,Xd,Y,Yd,status]=general_simplex(goal,c,A,b,csigns,vsigns)