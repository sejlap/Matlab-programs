function []=test4()
%Z=Nan Dopustiva oblast ne postoji; status(4)
goal='max';

c=[3 5];
A=[-1 0; 0 2; 3 2; 1 3; 2 3];
b=[4; 12; 18; 21; 6];
csigns=[1; 1; -1; -1; 1];
vsigns=[1; 1];
[Z,X,Xd,Y,Yd,status]=general_simplex(goal,c,A,b,csigns,vsigns)