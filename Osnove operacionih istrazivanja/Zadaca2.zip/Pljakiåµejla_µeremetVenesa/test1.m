function []=test1()
%Z=265.7143;  X=(3.4286 4.2857) Xd(0.1429 0.1286 0 0); Y(0 0 71.4286 42.8571) Yd(0 0); status(2)
goal='min';

c=[40 30];
A=[0.1 0; 0 0.1; 0.5 0.3; 0.1 0.2];
b=[0.2;0.3;3;1.2];
csigns=[1;1;1;1];
vsigns=[1; 1];
[Z,X,Xd,Y,Yd,status]=general_simplex(goal,c,A,b,csigns,vsigns)