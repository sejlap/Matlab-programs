function []=test3()
%Z=38;  X=(2/3 0 1/3 0) Xd(0 0.3 1/3); Y(0.12 0 0) Yd(0 36 0 34); status(1)
goal='min';

c=[32 56 50 60];
A=[1 1 1 1; 250 150 400 200; 0 0 0 1; 0 1 1 0];
b=[1; 300; 0.3; 0.5];
csigns=[0; 1;-1; -1];
vsigns=[1; 1; 1; 1];
[Z,X,Xd,Y,Yd,status]=general_simplex(goal,c,A,b,csigns,vsigns)