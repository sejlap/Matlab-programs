function []=test2()
%Z=900;  X=(300 0) Xd(0 30); Y(6 0) Yd(0 0.8); status(1)
goal='max';

c=[3 1];
A=[0.5 0.3; 0.1 0.2];
b=[150;60];
csigns=[-1;-1];
vsigns=[1; 1];
[Z,X,Xd,Y,Yd,status]=general_simplex(goal,c,A,b,csigns,vsigns)